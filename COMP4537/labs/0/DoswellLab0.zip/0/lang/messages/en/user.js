const messages = {prompt: "How many buttons to create?", invalidInput: "Invalid input", success: "Excellent memory!", failure: "Wrong order!"};

export default messages;